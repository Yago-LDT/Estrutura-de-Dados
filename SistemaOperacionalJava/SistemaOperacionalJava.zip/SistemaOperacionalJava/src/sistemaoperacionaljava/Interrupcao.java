package sistemaoperacionaljava;

public class Interrupcao implements Comparable<Interrupcao> {
    String dispositivo;
    int prioridade;
    
    public Interrupcao(String dispositivo, int prioridade){
        this.dispositivo = dispositivo;
        this.prioridade = prioridade;
    }
    
    @Override
    public int compareTo(Interrupcao outra) {
        return Integer.compare(outra.prioridade, this.prioridade); //max-heap
    }
    @Override
    public String toString(){
        return dispositivo + " (Prioridade: " + prioridade + ")";
    }
    
}
