package sistemaoperacionaljava;

import java.util.PriorityQueue;


public class ControladorInterrupcoes {
    public static void main(String[] args){
    PriorityQueue<Interrupcao> fila = new PriorityQueue<>();
    
    fila.add(new Interrupcao("Teclado", 2));
    fila.add(new Interrupcao("Disco Rígido", 4));
    fila.add(new Interrupcao("Mouse", 1));
    fila.add(new Interrupcao("Rede", 3));
    
    while(!fila.isEmpty()){
        System.out.println("Tratando a interrupção de: " + fila.poll());
    }
    }
}
