package sistemaoperacionaljava;

import java.util.PriorityQueue;

public class Escalonador {
 
    public static void main(String[] args) {
        PriorityQueue<Processo> fila = new PriorityQueue<>();
        
        fila.add(new Processo("Chrome", 4));
        fila.add(new Processo("Terminal", 2));
        fila.add(new Processo("IDE", 1));
        fila.add(new Processo("Player", 3));
        
        while (!fila.isEmpty()){
            System.out.println("Executando: " + fila.poll());
        }
    }
    
}
