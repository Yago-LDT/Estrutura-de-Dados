package sistemaoperacionaljava;


public class Processo implements Comparable<Processo> {
    String nome;
    int prioridade; // quanto menor o número, maior a prioridade
    
    public Processo(String nome, int prioridade) {
        this.nome = nome;
        this.prioridade = prioridade;
    }
    
    @Override
    public int compareTo(Processo outro) {
    return Integer.compare(this.prioridade, outro.prioridade);
    }
    
    @Override
    public String toString(){
        return nome + " (Prioridade: " + prioridade + ")";
    }
    
}
