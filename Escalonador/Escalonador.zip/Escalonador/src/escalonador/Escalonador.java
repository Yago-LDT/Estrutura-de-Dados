package escalonador;

import java.util.Comparator;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;

public class Escalonador {

    public static void main(String[] args) {
        Queue<Processo> filaNormal = new LinkedList<>(); //Fila circular para Round Robin
        
        PriorityQueue<Processo> filaPrioridade = new PriorityQueue<>(Comparator.comparingInt(p -> p.prioridade));
        
        // Adiciona processos
        filaNormal.add(new Processo("P1", 3, 5));
        filaNormal.add(new Processo("P2", 2, 4));
        filaPrioridade.add(new Processo("P-Critico", 1, 3));
        
        int quantum = 2;
        while(!filaPrioridade.isEmpty() || !filaNormal.isEmpty()){
            if(!filaPrioridade.isEmpty()){
                Processo p = filaPrioridade.poll();
                int exec = Math.min(p.temporestante, quantum);
                System.out.println("Executado Prioritário: " + p.id + " por " + exec + " unidades");
                p.temporestante -=exec;
                if (p.temporestante > 0){
                    filaPrioridade.add(p);
                }else {
                    p = filaNormal.poll();
                    exec = Math.min(p.temporestante, quantum);
                    System.out.println("Executando: " + p.id + " por " + exec + " unidades");
                    p.temporestante -= exec;
                    if(p.temporestante > 0){
                        filaNormal.add(p); // volta para o fim da fila
                    }
                    
                }
            }
        }
    }
    
}
