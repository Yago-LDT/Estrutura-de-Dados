package escalonador;


public class Processo {
    String id;
    int prioridade; //menor valor, maior prioridade
    int temporestante;
    
    public Processo(String i, int p, int tr){
        this.id = i;
        this.prioridade = p;
        this.temporestante = tr;
    }
}
