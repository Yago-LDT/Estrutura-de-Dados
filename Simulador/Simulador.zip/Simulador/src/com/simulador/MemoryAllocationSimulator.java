package com.memoriaallocation;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class MemoryAllocationSimulator extends JFrame {
   
    private final JComboBox<String> comboBoxEstrategico;
    private final DefaultListModel<String> listaModeloProcessos;
    private final java.util.List<BlocoMemoria> BlocosMemoria; //Lista 
    private final java.util.List<Processo> processos; //Lista
    private final JPanel painelMemoria;
    private final JButton botaoAlocar, botaoResetar, botaoIOSimular;
    private final JTextField nomeCampo, tamanhoCampo;
    private JLabel rotuloStatusMemoria;
    
    private int proximoEncaixeIndex = 0;

    public MemoryAllocationSimulator() {
        super("Simulador de Alocação de Memória");

        setLayout(new BorderLayout());

        comboBoxEstrategico = new JComboBox<>(new String[]{
            "Primeiro Encaixe", "Melhor Encaixe", "Pior Encaixe", "Próximo Encaixe"
        });

        listaModeloProcessos = new DefaultListModel<>();
        processos = new ArrayList<>();

        BlocosMemoria = new ArrayList<>(Arrays.asList(
            new BlocoMemoria(0, 100),
            new BlocoMemoria(1, 150),
            new BlocoMemoria(2, 200),
            new BlocoMemoria(3, 250),
            new BlocoMemoria(4, 300),
            new BlocoMemoria(5, 350)
        ));

        // Painel de entrada
        JPanel painelEntrada = new JPanel(new GridLayout(2, 1));
        
        JPanel painelProcesso = new JPanel();
        
        painelProcesso.add(new JLabel("Nome:"));
        nomeCampo = new JTextField(5);
        painelProcesso.add(nomeCampo);

        painelProcesso.add(new JLabel("Tamanho:"));
        tamanhoCampo = new JTextField(5);
        painelProcesso.add(tamanhoCampo);

        botaoAlocar = new JButton("Alocar");
        painelProcesso.add(botaoAlocar);

        botaoResetar = new JButton("Reiniciar");
        painelProcesso.add(botaoResetar);

        botaoIOSimular = new JButton("Simular E/S bloqueante");
        painelProcesso.add(botaoIOSimular);

        painelEntrada.add(painelProcesso);

        JPanel painelEstrategia = new JPanel();
        painelEstrategia.add(new JLabel("Estratégia:"));
        painelEstrategia.add(comboBoxEstrategico);
        painelEntrada.add(painelEstrategia);

        add(painelEntrada, BorderLayout.NORTH);

        // Painel de memória
        painelMemoria = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                drawBlocosMemoria(g);
            }
        };
        painelMemoria.setPreferredSize(new Dimension(600, 400));
        add(painelMemoria, BorderLayout.CENTER);

        // Lista de processos
        JList<String> listaProcessos = new JList<>(listaModeloProcessos);
        add(new JScrollPane(listaProcessos), BorderLayout.EAST);

        // Exibição do status da memória
        rotuloStatusMemoria = new JLabel("Memória: Total: 0KB | Ocupado: 0KB | Livre: 0KB");
        add(rotuloStatusMemoria, BorderLayout.SOUTH);

        // Ações
        botaoAlocar.addActionListener(e -> {
            String nome = nomeCampo.getText().trim();
            int tamanho;
            try {
                tamanho = Integer.parseInt(tamanhoCampo.getText().trim());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Tamanho inválido");
                return;
            }

            String estrategia = (String) comboBoxEstrategico.getSelectedItem();
            Processo p = new Processo(nome, tamanho);
            processos.add(p);

            boolean successo = switch (estrategia) {
                case "Primeiro Encaixe" -> allocateFirstFit(p);
                case "Melhor Encaixe" -> allocateBestFit(p);
                case "Pior Encaixe" -> allocateWorstFit(p);
                case "Próximo Encaixe" -> allocateNextFit(p);
                default -> false;
            };

            if (successo) {
                listaModeloProcessos.addElement(p.toString());
                repaint();
            } else {
                JOptionPane.showMessageDialog(this, "Não foi possível alocar o processo.");
            }
            atualizarStatusMemoria();
        });

        botaoResetar.addActionListener(e -> {
            processos.clear();
            listaModeloProcessos.clear();
            BlocosMemoria.forEach(BlocoMemoria::clear);
            proximoEncaixeIndex = 0;
            atualizarStatusMemoria();
            repaint();
        });

        botaoIOSimular.addActionListener(e -> {
            if (processos.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Nenhum processo em execução.");
                return;
            }
            new Thread(() -> {
                Processo p = processos.get(new Random().nextInt(processos.size()));
                p.bloqueado = true;
                repaint();
                try {
                    Thread.sleep(3000); // Simula espera por E/S
                } catch (InterruptedException ignored) {}
                p.bloqueado = false;
                repaint();
            }).start();
        });

        pack();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private boolean allocateFirstFit(Processo p) {
        for (BlocoMemoria bloco : BlocosMemoria) {
            if (bloco.isFree() && bloco.tamanho >= p.tamanho) {
                bloco.allocate(p);
                return true;
            }
        }
        return false;
    }

    private boolean allocateBestFit(Processo p) {
        BlocoMemoria melhor = null;
        for (BlocoMemoria bloco : BlocosMemoria) {
            if (bloco.isFree() && bloco.tamanho >= p.tamanho) {
                if (melhor == null || bloco.tamanho < melhor.tamanho) {
                    melhor = bloco;
                }
            }
        }
        if (melhor != null) {
            melhor.allocate(p);
            return true;
        }
        return false;
    }

    private boolean allocateWorstFit(Processo p) {
        BlocoMemoria pior = null;
        for (BlocoMemoria bloco : BlocosMemoria) {
            if (bloco.isFree() && bloco.tamanho >= p.tamanho) {
                if (pior == null || bloco.tamanho> pior.tamanho) {
                    pior = bloco;
                }
            }
        }
        if (pior != null) {
            pior.allocate(p);
            return true;
        }
        return false;
    }

    private boolean allocateNextFit(Processo p) {
        int n = BlocosMemoria.size();
        for (int i = 0; i < n; i++) {
            int index = (proximoEncaixeIndex + i) % n;
            BlocoMemoria bloco = BlocosMemoria.get(index);
            if (bloco.isFree() && bloco.tamanho >= p.tamanho) {
                bloco.allocate(p);
                proximoEncaixeIndex = (index + 1) % n;
                return true;
            }
        }
        return false;
    }

    private void drawBlocosMemoria(Graphics g) {
        int y = 20;
        for (BlocoMemoria bloco : BlocosMemoria) {
            g.setColor(bloco.processo == null ? Color.LIGHT_GRAY : (bloco.processo.bloqueado ? Color.ORANGE : Color.GREEN));
            g.fillRect(50, y, 200, 40);
            g.setColor(Color.BLACK);
            g.drawRect(50, y, 200, 40);
            g.drawString("Bloco " + bloco.id + ": " + bloco.tamanho + "KB", 60, y + 15);
            if (bloco.processo != null) {
                g.drawString(bloco.processo.nome + " (" + bloco.processo.tamanho + "KB)", 60, y + 35);
            }
            y += 60;
        }
    }

    private void atualizarStatusMemoria() {
        int memoriaTotal = 0;
        int memoriaUsada = 0;

        for (BlocoMemoria bloco : BlocosMemoria) {
            memoriaTotal += bloco.tamanho;
            if (bloco.processo != null) {
                memoriaUsada += bloco.tamanho;
            }
        }

        int memoriaLivre = memoriaTotal - memoriaUsada;
        rotuloStatusMemoria.setText("Memória: Total: " + memoriaTotal + "KB | Ocupado: " + memoriaUsada + "KB | Livre: " + memoriaLivre + "KB");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MemoryAllocationSimulator::new);
    }

    // Classes auxiliares

    static class BlocoMemoria {
        int id, tamanho;
        Processo processo;

        BlocoMemoria(int id, int tamanho) {
            this.id = id;
            this.tamanho = tamanho;
        }

        boolean isFree() {
            return processo == null;
        }

        void allocate(Processo p) {
            this.processo = p;
        }

        void clear() {
            this.processo = null;
        }
    }

    static class Processo {
        String nome;
        int tamanho;
        boolean bloqueado = false;

        Processo(String nome, int tamanho) {
            this.nome = nome;
            this.tamanho = tamanho;
        }

        public String toString() {
            return nome + " (" + tamanho + "KB)" + (bloqueado ? " [BLOQUEADO]" : "");
        }
    }
}
