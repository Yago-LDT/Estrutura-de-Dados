import java.util.*;

public class RedBlackTreeDemo {
    public static void main(String[] args) {
        TreeMap<Integer, String> processos = new TreeMap<>();
        processos.put(10, "Processo A");
        processos.put(20, "Processo B");
        processos.put(15, "Processo C");

        for (Map.Entry<Integer, String> entrada : processos.entrySet()) {
            System.out.println("Prioridade: " + entrada.getKey() + ", Nome: " + entrada.getValue());
        }
    }
}