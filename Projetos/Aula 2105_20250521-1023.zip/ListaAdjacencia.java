import java.util.*; // Importa todas as classes utilitárias do Java, como Map, List, HashMap, etc.

public class ListaAdjacencia { // Declaração da classe ListaAdjacencia
    private Map<Integer, List<Integer>> grafo = new HashMap<>(); // Mapa que representa o grafo: cada vértice aponta para uma lista de vizinhos

    public void adicionarAresta(int de, int para) { // Método para adicionar uma aresta ao grafo
        grafo.computeIfAbsent(de, k -> new ArrayList<>()).add(para); // Se não existe a lista de 'de', cria; depois adiciona 'para' como vizinho
    }

    public void imprimir() { // Método para imprimir o grafo
        for (Map.Entry<Integer, List<Integer>> entrada : grafo.entrySet()) { // Para cada vértice e sua lista de vizinhos
            System.out.println("" + entrada.getKey() + " -> " + entrada.getValue()); // Imprime o vértice e seus vizinhos
        }
    }

    public static void main(String[] args) { // Método principal para testar a classe
        ListaAdjacencia la = new ListaAdjacencia(); // Cria uma instância da classe
        la.adicionarAresta(1, 2); // Adiciona aresta de 1 para 2
        la.adicionarAresta(1, 3); // Adiciona aresta de 1 para 3
        la.adicionarAresta(2, 4); // Adiciona aresta de 2 para 4
        la.adicionarAresta(4, 1); // Adiciona aresta de 4 para 1 (pode formar um ciclo)

        la.imprimir(); // Imprime o grafo
    }
}