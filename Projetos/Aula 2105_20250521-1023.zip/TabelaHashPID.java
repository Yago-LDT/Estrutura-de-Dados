import java.util.*;

public class TabelaHashPID {
    public static void main(String[] args) {
        Map<Integer, String> tabelaPID = new HashMap<>();
        tabelaPID.put(1001, "Processo X");
        tabelaPID.put(1002, "Processo Y");

        System.out.println("PID 1001: " + tabelaPID.get(1001)); // "Processo X"
    }
}