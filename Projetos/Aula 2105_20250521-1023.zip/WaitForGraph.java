import java.util.*; // Importa todas as classes utilitárias do Java, como Map, List, HashMap, etc.

public class WaitForGraph { // Declaração da classe WaitForGraph
    private Map<Integer, List<Integer>> graph = new HashMap<>(); // Cria um mapa para representar o grafo de espera

    public void adicionarAresta(int de, int para) { // Método para adicionar uma aresta ao grafo
        graph.computeIfAbsent(de, k -> new ArrayList<>()).add(para); // Adiciona 'para' à lista de vizinhos de 'de'
    }

    public boolean temCiclo() { // Método para verificar se há ciclo (deadlock) no grafo
        Set<Integer> visitado = new HashSet<>(); // Conjunto de nós já visitados
        Set<Integer> pilha = new HashSet<>(); // Conjunto de nós na pilha de recursão (para detectar ciclos)

        for (Integer processo : graph.keySet()) { // Para cada nó do grafo
            if (dfs(processo, visitado, pilha)) return true; // Se encontrar ciclo, retorna true
        }
        return false; // Se não encontrar ciclo, retorna false
    }

    private boolean dfs(int atual, Set<Integer> visitado, Set<Integer> pilha) { // Busca em profundidade (DFS)
        if (pilha.contains(atual)) return true; // Se o nó já está na pilha, há ciclo
        if (visitado.contains(atual)) return false; // Se já foi visitado e não está na pilha, não há ciclo

        visitado.add(atual); // Marca como visitado
        pilha.add(atual); // Adiciona à pilha

        for (int vizinho : graph.getOrDefault(atual, Collections.emptyList())) { // Para cada vizinho do nó atual
            if (dfs(vizinho, visitado, pilha)) return true; // Chama recursivamente e verifica ciclo
        }

        pilha.remove(atual); // Remove da pilha ao voltar da recursão
        return false; // Não encontrou ciclo
    }

    public static void main(String[] args) { // Método principal para testar o grafo
        WaitForGraph wfg = new WaitForGraph(); // Cria uma instância do grafo
        wfg.adicionarAresta(1, 2); // Adiciona aresta de 1 para 2
       // wfg.adicionarAresta(2, 3); // Adiciona aresta de 2 para 3
        wfg.adicionarAresta(3, 1); // Adiciona aresta de 3 para 1 (forma um ciclo)

        System.out.println("Deadlock detectado? " + wfg.temCiclo()); // Imprime se há deadlock (ciclo)
    }
}